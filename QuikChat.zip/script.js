const chatContainer = document.getElementById("chat-container");
const userInput = document.getElementById("user-input");
const sendBtn = document.getElementById("send-btn");

// Typewriter effect
function typeWriterEffect(element, text, speed = 20) {
  let i = 0;
  function typing() {
    if (i < text.length) {
      element.innerHTML += text.charAt(i);
      i++;
      setTimeout(typing, speed);
    }
  }
  typing();
}

function addMessage(text, sender) {
  const messageDiv = document.createElement("div");
  messageDiv.classList.add("message", sender);
  if (sender === "ai") {
    typeWriterEffect(messageDiv, text, 15);
  } else {
    messageDiv.textContent = text;
  }
  chatContainer.appendChild(messageDiv);
  chatContainer.scrollTop = chatContainer.scrollHeight;
}

async function getAIResponse(userText) {
  // Simple local responses (demo)
  userText = userText.toLowerCase();
  if (userText.includes("hello")) return "Hello! How are you today?";
  if (userText.includes("1+1")) return "1+1 is 2.";
  if (userText.includes("name")) return "I am QuikChat AI.";
  if (userText.includes("weather")) return "I can't check weather live yet, but I can chat with you!";
  return "That's interesting! Tell me more.";
}

sendBtn.addEventListener("click", async () => {
  const text = userInput.value.trim();
  if (!text) return;
  if (text.length > 200) {
    addMessage("Max 200 words allowed.", "ai");
    return;
  }

  addMessage(text, "user");
  userInput.value = "";
  
  setTimeout(async () => {
    const aiText = await getAIResponse(text);
    addMessage(aiText, "ai");
  }, 500);
});

userInput.addEventListener("keypress", (e) => {
  if (e.key === "Enter") {
    sendBtn.click();
  }
});
